const AnekdotController = require('./AnekdotController');
const AuthController = require('./AuthController');
const FavouritesController = require('./FavouritesController');
const FeedController = require('./FeedController');

module.exports = {
  AnekdotController,
  AuthController,
  FavouritesController,
  FeedController,
};
