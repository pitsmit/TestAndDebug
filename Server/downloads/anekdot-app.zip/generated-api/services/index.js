const AnekdotService = require('./AnekdotService');
const AuthService = require('./AuthService');
const FavouritesService = require('./FavouritesService');
const FeedService = require('./FeedService');

module.exports = {
  AnekdotService,
  AuthService,
  FavouritesService,
  FeedService,
};
